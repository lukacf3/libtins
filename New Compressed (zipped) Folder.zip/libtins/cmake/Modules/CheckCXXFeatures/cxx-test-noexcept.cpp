int foo() noexcept {
    return 0;
}

int main() {
    return foo();
}
